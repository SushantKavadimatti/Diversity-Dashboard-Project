import pandas as pd
import os

def initialize_data():
    """Initialize CSV files if they don't exist"""
    # Create data directory if it doesn't exist
    if not os.path.exists('data'):
        os.makedirs('data')
    
    # Initialize surveys.csv
    if not os.path.exists('data/surveys.csv'):
        surveys_df = pd.DataFrame(columns=[
            'survey_id',
            'title',
            'description',
            'created_at'
        ])
        surveys_df.to_csv('data/surveys.csv', index=False)
    
    # Initialize responses.csv
    if not os.path.exists('data/responses.csv'):
        responses_df = pd.DataFrame(columns=[
            'response_id',
            'survey_id',
            'timestamp',
            'gender',
            'age',
            'ethnicity',
            'department',
            'role',
            'years_experience'
        ])
        responses_df.to_csv('data/responses.csv', index=False)

def save_survey_response(response_data):
    """Save a new survey response"""
    try:
        responses_df = pd.read_csv('data/responses.csv')
        response_data['response_id'] = len(responses_df) + 1
        responses_df = pd.concat([responses_df, pd.DataFrame([response_data])], ignore_index=True)
        responses_df.to_csv('data/responses.csv', index=False)
        return True
    except Exception as e:
        print(f"Error saving response: {str(e)}")
        return False

def export_data():
    """Export all data as DataFrames"""
    try:
        surveys_df = pd.read_csv('data/surveys.csv')
        responses_df = pd.read_csv('data/responses.csv')
        return surveys_df, responses_df
    except Exception as e:
        print(f"Error exporting data: {str(e)}")
        return None, None
