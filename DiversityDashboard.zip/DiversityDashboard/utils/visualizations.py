import plotly.express as px
import plotly.graph_objects as go

def plot_gender_distribution(df):
    """Create a pie chart for gender distribution"""
    fig = px.pie(
        df,
        names='gender',
        title='Gender Distribution',
        color_discrete_sequence=px.colors.qualitative.Set3
    )
    fig.update_traces(textposition='inside', textinfo='percent+label')
    return fig

def plot_ethnic_diversity(df):
    """Create a bar chart for ethnic diversity"""
    ethnicity_counts = df['ethnicity'].value_counts()
    fig = px.bar(
        x=ethnicity_counts.index,
        y=ethnicity_counts.values,
        title='Ethnic Diversity',
        labels={'x': 'Ethnicity', 'y': 'Count'},
        color_discrete_sequence=px.colors.qualitative.Set3
    )
    return fig

def plot_age_demographics(df):
    """Create a histogram for age distribution"""
    fig = px.histogram(
        df,
        x='age',
        nbins=20,
        title='Age Demographics',
        labels={'age': 'Age', 'count': 'Count'},
        color_discrete_sequence=px.colors.qualitative.Set3
    )
    return fig

def plot_department_distribution(df):
    """Create a horizontal bar chart for department distribution"""
    dept_counts = df['department'].value_counts()
    fig = px.bar(
        x=dept_counts.values,
        y=dept_counts.index,
        orientation='h',
        title='Department Distribution',
        labels={'x': 'Count', 'y': 'Department'},
        color_discrete_sequence=px.colors.qualitative.Set3
    )
    return fig

def plot_trend_over_time(df, metric):
    """Create a line chart for trend analysis"""
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    trend_data = df.groupby('timestamp')[metric].count()
    
    fig = px.line(
        x=trend_data.index,
        y=trend_data.values,
        title=f'{metric} Trend Over Time',
        labels={'x': 'Date', 'y': 'Count'},
        color_discrete_sequence=px.colors.qualitative.Set3
    )
    return fig
