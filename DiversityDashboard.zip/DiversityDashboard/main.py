import streamlit as st
import pandas as pd
from utils.data_handler import initialize_data
from utils.visualizations import (
    plot_gender_distribution,
    plot_ethnic_diversity,
    plot_age_demographics,
    plot_department_distribution
)

# Page configuration
st.set_page_config(
    page_title="Diversity Metrics Dashboard",
    page_icon="📊",
    layout="wide"
)

# Initialize session state
if 'data_initialized' not in st.session_state:
    initialize_data()
    st.session_state.data_initialized = True

# Main dashboard title
st.title("📊 Diversity Metrics Dashboard")

# Load data
try:
    responses_df = pd.read_csv('data/responses.csv')
    
    # Dashboard layout
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("Gender Distribution")
        fig_gender = plot_gender_distribution(responses_df)
        st.plotly_chart(fig_gender, use_container_width=True)
        
        st.subheader("Age Demographics")
        fig_age = plot_age_demographics(responses_df)
        st.plotly_chart(fig_age, use_container_width=True)
        
    with col2:
        st.subheader("Ethnic Diversity")
        fig_ethnic = plot_ethnic_diversity(responses_df)
        st.plotly_chart(fig_ethnic, use_container_width=True)
        
        st.subheader("Department Distribution")
        fig_dept = plot_department_distribution(responses_df)
        st.plotly_chart(fig_dept, use_container_width=True)
    
    # Summary metrics
    st.subheader("Key Metrics")
    metric_col1, metric_col2, metric_col3, metric_col4 = st.columns(4)
    
    with metric_col1:
        total_responses = len(responses_df)
        st.metric("Total Responses", total_responses)
        
    with metric_col2:
        gender_ratio = responses_df['gender'].value_counts().to_dict()
        st.metric("Gender Ratio (F:M)", f"1:{round(gender_ratio.get('Male', 0)/gender_ratio.get('Female', 1), 2)}")
        
    with metric_col3:
        avg_age = responses_df['age'].mean()
        st.metric("Average Age", f"{round(avg_age, 1)}")
        
    with metric_col4:
        dept_count = responses_df['department'].nunique()
        st.metric("Departments", dept_count)

except Exception as e:
    st.error(f"Error loading data: {str(e)}")
    st.info("Please add some survey responses to view the dashboard.")
