import streamlit as st
import pandas as pd
from datetime import datetime
from utils.data_handler import save_survey_response

st.set_page_config(page_title="Survey Form", page_icon="📝")

st.title("📝 Diversity Survey Form")

with st.form("survey_form"):
    st.write("Please fill out the following information:")
    
    # Basic Information
    gender = st.selectbox(
        "Gender",
        ["Female", "Male", "Non-binary", "Prefer not to say"]
    )
    
    age = st.number_input(
        "Age",
        min_value=18,
        max_value=100,
        value=30
    )
    
    ethnicity = st.selectbox(
        "Ethnicity",
        [
            "Asian",
            "Black or African American",
            "Hispanic or Latino",
            "White",
            "Native American",
            "Pacific Islander",
            "Other",
            "Prefer not to say"
        ]
    )
    
    # Professional Information
    department = st.selectbox(
        "Department",
        [
            "Engineering",
            "Sales",
            "Marketing",
            "Human Resources",
            "Finance",
            "Operations",
            "Other"
        ]
    )
    
    role = st.text_input("Job Title")
    
    years_experience = st.slider(
        "Years of Experience",
        min_value=0,
        max_value=50,
        value=5
    )
    
    submitted = st.form_submit_button("Submit Survey")
    
    if submitted:
        response_data = {
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'survey_id': 1,  # Default survey ID
            'gender': gender,
            'age': age,
            'ethnicity': ethnicity,
            'department': department,
            'role': role,
            'years_experience': years_experience
        }
        
        if save_survey_response(response_data):
            st.success("Thank you for completing the survey!")
        else:
            st.error("There was an error saving your response. Please try again.")
