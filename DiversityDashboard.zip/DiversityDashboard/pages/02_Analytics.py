import streamlit as st
import pandas as pd
from utils.visualizations import plot_trend_over_time
from utils.data_handler import export_data

st.set_page_config(page_title="Analytics", page_icon="📈")

st.title("📈 Detailed Analytics")

# Load data
try:
    surveys_df, responses_df = export_data()
    
    # Time-based analysis
    st.subheader("Trends Over Time")
    metric_choice = st.selectbox(
        "Select metric to analyze",
        ["gender", "ethnicity", "department"]
    )
    
    trend_fig = plot_trend_over_time(responses_df, metric_choice)
    st.plotly_chart(trend_fig, use_container_width=True)
    
    # Data export section
    st.subheader("Export Data")
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("Export Responses CSV"):
            csv = responses_df.to_csv(index=False)
            st.download_button(
                label="Download Responses",
                data=csv,
                file_name="diversity_survey_responses.csv",
                mime="text/csv"
            )
    
    with col2:
        if st.button("Export Surveys CSV"):
            csv = surveys_df.to_csv(index=False)
            st.download_button(
                label="Download Surveys",
                data=csv,
                file_name="diversity_surveys.csv",
                mime="text/csv"
            )
    
    # Summary statistics
    st.subheader("Summary Statistics")
    
    # Gender balance
    st.write("Gender Balance")
    st.dataframe(responses_df['gender'].value_counts(normalize=True).round(2))
    
    # Age statistics
    st.write("Age Statistics")
    st.dataframe(responses_df['age'].describe().round(2))
    
    # Department distribution
    st.write("Department Distribution")
    st.dataframe(responses_df['department'].value_counts(normalize=True).round(2))

except Exception as e:
    st.error(f"Error loading data: {str(e)}")
    st.info("Please add some survey responses to view analytics.")
